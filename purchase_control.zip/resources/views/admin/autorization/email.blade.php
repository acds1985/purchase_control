<h1>Olá Sr. {{ $user }}</h1>
<h3>Segue o token para Liberação da AF-{{$af}} - <b class="btn btn-danger">{{$token}}</b></h3>
<hr><br>
<h5>E-mail enviando em: {{ date('d/m/Y H:i:s') }}</h5>