$(function(){
    alert("hello world");
});