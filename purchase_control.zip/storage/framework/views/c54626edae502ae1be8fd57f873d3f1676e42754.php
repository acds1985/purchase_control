<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">AFs - Autorizações de Fornecimento</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo e(route('autorization.index')); ?>">AFs</a></li>
            <li class="breadcrumb-item active">Lista</li>
          </ol>
        </div><!-- /.col -->

      </div><!-- /.row -->
      
      
    </div><!-- /.container-fluid -->
    <?php if(session()->exists('message')): ?>
      <div class="alert <?php echo e(session()->get('color')); ?>"><i class="fas fa-check"></i> <?php echo e(session()->get('message')); ?></div>
    <?php endif; ?>
  </div>
  <!-- /.content-header -->

<div class="content">
  <!-- /.container-fluid -->
  <div class="card">
    <div class="card-header">
      <a href="<?php echo e(route('autorization.create')); ?>" class="btn btn-primary text-rigth"><i class="fas fa-plus"></i> Adicionar</a>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
      <table id="example1" class="table table-bordered table-striped">
        <thead>
        <tr class="text-center">        
          <th>AF ID</th>
          <th>Cliente/Centro Custo</th>
          <th>Valor (R$)</th>
          <th>Fornecedor</th>
          <th>Filial</th>
          <th>Status</th>
          <th class="text-center" style="width: 200px">Ações</th>
        </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $autorizations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autorization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>           
              <td class="text-primary"><b>AF<?php echo e($autorization->id); ?></b></td>
              <td><?php echo e($autorization->client()->first()->social_name); ?></td>
              <td><?php echo e($autorization->price); ?></td>
              <td><?php echo e($autorization->provider()->first()->social_name); ?></td>     
              <td><?php echo e($autorization->branch()->first()->social_name); ?></td>     
              <td>
                <?php
                  if($autorization->status == 0){
                    echo "<span class='badge badge-warning'>Aguardando</span>";
                  }elseif ($autorization->status == 1) {
                    echo "<span class='badge badge-success'>Autorizada</span>";
                  }else{
                    echo "<span class='badge badge-danger'>Cancelada</span>";
                  }
                ?>
              </td>     
              <td style="width: auto" class="text-center">
                <?php if($autorization->status == 1): ?>
                  <a href="" class="btn btn-sm btn-warning" title="Gerar PDF"><i class="fas fa-file-pdf"></i></a>
                <?php else: ?>
                  <a href="<?php echo e(route('autorization.edit', ['client'=> $autorization->id])); ?>" class="btn btn-sm btn-primary" title="Editar AF"><i class="fas fa-edit"></i></a>           
                <?php endif; ?>
                <a href="<?php echo e(route('autorization.show', ['client'=> $autorization->id])); ?>" class="btn btn-sm btn-secondary" title="Visualizar AF"><i class="fas fa-eye"></i></a>
                <a href="<?php echo e(route('autorization.inative', ['client'=> $autorization->id])); ?>" class="btn btn-sm btn-danger" title="Cancelar AF"><i class="fas fa-trash-alt" ></i></a>
              </td>
            </tr>    
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
        </tbody>
        
      </table>
    </div>
    <!-- /.card-body -->
  </div>
  <!-- /.card -->
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>