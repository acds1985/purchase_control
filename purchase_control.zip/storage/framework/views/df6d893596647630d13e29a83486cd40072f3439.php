<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">Filiais</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo e(route('users.index')); ?>">Filiais</a></li>
            <li class="breadcrumb-item active">Lista</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->

<div class="content">
  <!-- /.container-fluid -->
  <div class="card">
    <div class="card-header">
      <a href="<?php echo e(route('branches.create')); ?>" class="btn btn-primary text-rigth"><i class="fas fa-plus"></i> Adicionar</a>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
      <table id="example1" class="table table-bordered table-striped">
        <thead>
        <tr class="text-center">        
          <th>Razão Social</th>
          <th>Nome Fantasia</th>
          <th>CNPJ</th>
          <th>IE</th>
          <th>Responsavél</th>
          <th class="text-center" style="width: 200px">Ações</th>
        </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>           
              <td class="text-primary"><b><?php echo e($branch->social_name); ?></b></td>
              <td><?php echo e($branch->alias_name); ?></td>
              <td><?php echo e($branch->document_company); ?></td>
              <td><?php echo e($branch->document_company_secondary); ?></td>     
              <td><a href="<?php echo e(route('users.edit', ['user'=> $branch->user()->first()->id])); ?>" ><?php echo e($branch->user()->first()->name); ?></a></td>
              <td style="width: auto" class="text-center">
                <a href="<?php echo e(route('branches.edit', ['branch'=> $branch->id])); ?>" title="Editar Filial" class="btn btn-sm btn-primary"><i class="fas fa-edit"></i></a>
                <a href="" class="btn btn-sm btn-danger" title="Excluir Filial"><i class="fas fa-trash-alt"></i></a>
              </td>
            </tr>    
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
        </tbody>
        
      </table>
    </div>
    <!-- /.card-body -->
  </div>
  <!-- /.card -->
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>