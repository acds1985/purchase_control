<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>PurchaseControl 1.0 | Log in</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo e(url('css/fontawesome-free/css/all.min.css')); ?>">
  
  <!-- icheck bootstrap -->
  <link rel="stylesheet" href="<?php echo e(url('css/icheck/icheck-bootstrap.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('css/toasts.css')); ?>">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo e(url('css/admin.css')); ?>">

  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<body class="hold-transition login-page">
<div class="login-box">
  <!-- /.login-logo -->
  <div class="card card-outline card-primary">
    <div class="card-header text-center">
      <a href="" class="h1"><b>Purchase</b>Control</a>
    </div>
   
    <div class="card-body">
      <p class="login-box-msg">Informe seus dados de acesso.</p>

      <form name="login" action="<?php echo e(route('login.do')); ?>" method="post" autocomplete="off">
        <?php echo csrf_field(); ?>
        <div class="input-group mb-3">
          <input type="email" class="form-control" placeholder="Email" name="email" value="andrecorreia0605@gmail.com">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fa fa-envelope"></span>
            </div>
          </div>
        </div>
        <div class="input-group mb-3">
          <input type="password" class="form-control" placeholder="Password" name="password">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fa fa-lock"></span>
            </div>
          </div>
        </div>
        <div class="row">
          
          <!-- /.col -->
          <div class="col-12">
            <button type="submit" class="btn btn-primary btn-block"><i class="fas fa-sign-in-alt"></i>
               Logar</button>
          </div>
          <!-- /.col -->
        </div>
      </form>

    </div>
    <!-- /.card-body -->
  </div>
  <!-- /.card -->
</div>
<!-- /.login-box -->

<!-- jQuery -->
<script src="<?php echo e(url('js/jquery.js')); ?>"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(url('js/bootstrap.js')); ?>"></script>
<script src="<?php echo e(url('js/toastr.js')); ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(url('js/adminLte.js')); ?>"></script>
<script src="<?php echo e(url('js/login.js')); ?>"></script>
</body>
</html>
