<h1>Olá Sr. <?php echo e($user); ?></h1>
<h3>Segue o token para Liberação da AF-<?php echo e($af); ?> - <b class="btn btn-danger"><?php echo e($token); ?></b></h3>
<hr><br>
<h5>E-mail enviando em: <?php echo e(date('d/m/Y H:i:s')); ?></h5>