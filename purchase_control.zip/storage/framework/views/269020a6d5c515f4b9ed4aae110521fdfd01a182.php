<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Editar Cliente</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(route('clients.index')); ?>">Cliente</a></li>
              <li class="breadcrumb-item active">Editar</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
              <!-- left column -->
              <div class="col-md-12">
                <?php if($errors->all()): ?>
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger"><i class="fas fa-asteristc"></i><?php echo e($error); ?></div>                 
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                <?php if(session()->exists('message')): ?>
                  <div class="alert <?php echo e(session()->get('color')); ?>"><i class="fas fa-check"></i> <?php echo e(session()->get('message')); ?></div>
                <?php endif; ?>
                <!-- general form elements -->
                <div class="card card-primary">
                  <div class="card-header">
                    <h3 class="card-title">Formulario de Edição</h3>
                  </div>
                  <!-- /.card-header -->
                  <!-- form start -->
                  <form method="post" action="<?php echo e(route('clients.update', ['client' => $client->id])); ?>">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field('PUT'); ?>
                      <input type="hidden" name="id" value="<?php echo e($client->id); ?>">
                    <div class="card-body row">
                      <div class="form-group col-md-6">
                        <label for="name">Razao Social</label>
                        <input type="social_name" class="form-control" id="social_name" name="social_name" placeholder="Informe a razao social"
                        value="<?php echo e(old('social_name') ?? $client->social_name); ?>">
                      </div>
                      <div class="form-group col-md-6">
                        <label for="alias_name">Nome Fantasia</label>
                        <input type="text" class="form-control" id="alias_name" name="alias_name" placeholder="Informe nome fantasia"
                        value="<?php echo e(old('alias_name') ?? $client->alias_name); ?>">
                      </div>
                      <div class="form-group col-md-6">
                        <label for="document_company">CNPJ</label>
                        <input type="tel" class="form-control mask-cnpj" id="document_company" name="document_company" placeholder="Informe o CNPJ"
                        value="<?php echo e(old('document_company') ?? $client->document_company); ?>">
                      </div>
                      <div class="form-group col-md-6">
                        <label for="document_company_secondary">Inscrição Estadual</label>
                        <input type="text" class="form-control" id="document_company_secondary" name="document_company_secondary" placeholder="Informe a Incricao estadual"
                        value="<?php echo e(old('document_company_secondary') ?? $client->document_company_secondary); ?>">
                      </div>

                      <div class="form-group col-md-2">
                        <label for="zipcode">CEP</label>
                        <input type="text" class="form-control mask-zipcode zip_code_search" id="zipcode" name="zipcode" placeholder="Informe o CEP"
                        value="<?php echo e(old('zipcode') ?? $client->zipcode); ?>">
                      </div>
                      <div class="form-group col-md-6">
                        <label for="street">Rua / Logradouro</label>
                        <input type="text" class="form-control street" id="street" name="street" placeholder="Informe endereco"
                        value="<?php echo e(old('street') ?? $client->street); ?>">
                      </div>
                      <div class="form-group col-md-4">
                        <label for="number">Numero</label>
                        <input type="text" class="form-control" id="number" name="number" placeholder="Informe o numero"
                        value="<?php echo e(old('number') ?? $client->number); ?>">
                      </div>
                      <div class="form-group col-md-6">
                        <label for="complement">Complemento</label>
                        <input type="text" class="form-control" id="complement" name="complement" placeholder="Informe o complemento"
                        value="<?php echo e(old('complement') ?? $client->complement); ?>">
                      </div>
                      <div class="form-group col-md-6">
                        <label for="neighborhood">Bairro</label>
                        <input type="text" class="form-control neighborhood" id="neighborhood" name="neighborhood" placeholder="Informe o bairro"
                        value="<?php echo e(old('neighborhood') ?? $client->neighborhood); ?>">
                      </div>
                      <div class="form-group col-md-6">
                        <label for="state">Estado</label>
                        <input type="text" class="form-control state" id="state" name="state" placeholder="Informe o estado"
                        value="<?php echo e(old('state') ?? $client->state); ?>">
                      </div>
                      <div class="form-group col-md-6">
                        <label for="city">Cidade</label>
                        <input type="text" class="form-control city" id="city" name="city" placeholder="Informe a cidade"
                        value="<?php echo e(old('city') ?? $client->city); ?>">
                      </div>
                      <div class="form-group col-md-6">
                        <label for="telephone">Telefone</label>
                        <input type="text" class="form-control mask-cell" id="telephone" name="telephone" placeholder="Informe um telefone para contato"
                        value="<?php echo e(old('telephone') ?? $client->telephone); ?>">
                      </div>
                      <div class="form-group col-md-6">
                        <label for="email">E-mail</label>
                        <input type="email" class="form-control email" id="email" name="email" placeholder="E-mail para contato"
                        value="<?php echo e(old('email') ?? $client->email); ?>">
                      </div>
                      <div class="form-group col-md-6">
                        <label for="contact">Contato</label>
                        <input type="text" class="form-control contact" id="contact" name="contact" placeholder="Pessoa de Contato"
                        value="<?php echo e(old('contact') ?? $client->contact); ?>">
                      </div>
                      <div class="form-group col-md-6">
                        <label for="function">Cargo/Função</label>
                        <input type="text" class="form-control" id="function" name="function" placeholder="Informe o Cargo ou Função"
                        value="<?php echo e(old('function') ?? $client->function); ?>">
                      </div>
                            
                    </div>
                    <!-- /.card-body -->
                    <div class="card-footer">
                      <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Atualizar</button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>